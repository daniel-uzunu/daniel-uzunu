console.log('Hello, JavaScript!');
